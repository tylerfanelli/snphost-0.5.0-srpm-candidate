# snphost
Management CLI for SEV-SNP host system administrators

Please consult `docs/snphost.1.adoc` for an overview of `snphost` and
descriptions of each `snphost` subcommand.
